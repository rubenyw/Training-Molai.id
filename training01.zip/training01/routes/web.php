<?php

use App\Http\Controllers\Controller;
use App\Http\Controllers\MyController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view("welcome");
});

Route::get('/home', [MyController::class, "HomePage"])->name("homepage");
Route::get('/main', [MyController::class, "MainPage"])->name("mainpage");
Route::get('/coba', [MyController::class, "CobaPage"])->name("cobapage");

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <?php
        $data = [
            [
                "Nama" => "Eric",
                "IPK" => floatval(2.1),
                "Nilai" => [
                    "UTS" => 30,
                    "UAS" => 50,
                ]
            ],
            [
                "Nama" => "Fellya",
                "IPK" => floatval(2.1),
                "Nilai" => [
                    "UTS" => 30,
                    "UAS" => 50,
                ]
            ]    
        ];
    ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1>Nama :  <?php echo e($item["Nama"]); ?> </h1>
        <p>IPK :  <?php echo e($item["IPK"]); ?> </p>
        <p>Nilai UTS :  <?php echo e($item["Nilai"]["UTS"]); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button class="btn btn-primary" onclick="window.location.href='<?php echo e(route('homepage')); ?>'">
        To Home Page
    </button>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script><?php /**PATH D:\Ruben Pinjam\Kerja\Molai.id\Training Molai.id\training01\resources\views/home/mainpage.blade.php ENDPATH**/ ?>